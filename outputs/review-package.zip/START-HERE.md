# Start here: MARA-CR-001 reviewer package

This is a hypothetical credit-risk case. MARA is not represented as a Coinbase customer. The facility, collateral, policy limits, Base route, rating, and portfolio are fictional.

## Recommended review path

1. Open `outputs/committee-packet.pdf` for the decision, strongest opposing view, and reviewer question.
2. Open `outputs/decision-view.html` for scenario comparisons, decision thresholds, and the collateral-call cure ladder.
3. Inspect `outputs/credit-model.xlsx` for spreadsheet logic and sources.
4. Read `artifacts/readiness-report.md`, `artifacts/validation-report.md`, and `artifacts/package-metrics.md` before relying on any result.
5. Review `artifacts/liquidity-analysis.csv` for the public-data repayment screen and its limitations.
6. Review `artifacts/condition-register.csv`; all nine conditions currently block funding.
7. Review `artifacts/covenant-plan.csv` for the draft test, cure, consequence, owner, and linked monitoring rule.
8. Review `artifacts/escalation-playbook.csv` for response timing, draw state, decision ownership, required evidence, and exit criteria.
9. Use the live what-if lab in `outputs/decision-view.html`; its four boundary cases are declared in `artifacts/what-if-contract.json`.
10. Review `artifacts/scenario-attribution.csv` for quantified base deltas, binding drivers, and scenario-specific resolution evidence.
11. Review `artifacts/decision-lineage.csv` to trace committee claims to evidence, logic, artifacts, workbook cells, owners, and limitations.
12. Review `artifacts/diligence-plan.csv` for execution waves, parallel lanes, dependencies, decision impact, and completion evidence.
13. Review `artifacts/assumption-register.csv` for materiality, ownership, validation methods, challenge triggers, and downstream decision impact.
14. Review `artifacts/collateral-call-ladder.csv` for the modeled coverage breach point, cure amounts, and covenant-compliant commitment step-downs.
15. Review `artifacts/control-matrix.csv` to trace every pre-funding condition through its monitoring rule, draft covenant, escalation playbook, authority, and exit criteria.
16. Review `artifacts/model-risk-register.csv` for known model limitations, mitigations, evidence requirements, owners, and the required disposition if unresolved.
17. Use `artifacts/external-review-kit.md` and `outputs/reviewer-scorecard.pdf` to execute and document the independent human gates that remain outstanding without treating generated forms as validation.
18. Record completed gate evidence with `scripts/record_reviewer_gate.py`; the command rejects incomplete or unretained evidence and never treats local checks as human review.
19. Use `artifacts/reproducibility.md` to rebuild or independently reproduce the $3.04648 million collateral cap.

## Decision in one line

Conditionally approve no more than $3.0 million only after ownership, first priority, enforceable control, and the Base-to-cash route are evidenced; otherwise decline.

## Evidence boundary

Local verification is complete, but the package is not legally validated, production-ready, or ready for a real credit decision. Governed readiness currently records 0 of 3 human gates passed and 3 outstanding; ready to share is NO. Review the evidence ledger and readiness report for the exact gate-level state.

`BUNDLE-MANIFEST.json` lists every included file with its byte length and SHA-256 digest.
